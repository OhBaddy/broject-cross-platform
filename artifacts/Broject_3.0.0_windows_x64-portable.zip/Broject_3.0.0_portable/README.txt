Broject 3.0.0 — portable Windows

Estrai l'intera cartella e avvia Broject.exe.
Non spostare Broject.exe fuori dalla cartella: WebView2Loader.dll deve restare accanto all'app.

È necessario Microsoft WebView2 Runtime, normalmente già presente su Windows 10/11.
